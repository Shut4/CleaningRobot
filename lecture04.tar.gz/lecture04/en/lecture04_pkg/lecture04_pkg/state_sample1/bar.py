#!/usr/bin/env python3
# -*-encoding:UTF-8-*-

"""
File: bar.py
Author: Tomoaki Fujino（Kyushu Institute of Technology, Hibikino-Musashi@Home）
"""

# Import modules (ROS2 related)
import rclpy
from rclpy.duration import Duration
from rclpy.node import Node

# Import modules (YASMIN related)
# https://github.com/uleroboticsgroup/yasmin.git
from yasmin import State
from yasmin import Blackboard


class BarState(State):
    """BarState class (inherits from State class)"""

    def __init__(self, node: Node):
        """Class initialization method

        Args:
            node (Node): Node class object
        """
        # Override the constructor of the inherited State class
        # The outcomes argument specifies the possible results to return when the state completes
        super().__init__(outcomes=["outcome2"])

        # Create an instance of the Node object
        self.node = node

    def execute(self, blackboard: Blackboard) -> str:
        """
        BAR state execution method

        Args:
            blackboard (CustomBlackboard): CustomBlackboard object

        Returns:
            str: outcomes string
        """
        # Display log
        self.node.get_logger().info("Executing state BAR")

        # Wait for 3 seconds
        self.node.get_clock().sleep_for(Duration(seconds=3))

        # Display log
        self.node.get_logger().info(blackboard.foo_str)

        return "outcome2"