#!/usr/bin/env python3
# -*-encoding:UTF-8-*-

"""
File: foo.py
Author: Tomoaki Fujino（Kyushu Institute of Technology, Hibikino-Musashi@Home）
"""

# Import modules (ROS2 related)
import rclpy
from rclpy.duration import Duration
from rclpy.node import Node

# Import modules (YASMIN related)
# https://github.com/uleroboticsgroup/yasmin.git
from yasmin import State
from yasmin import Blackboard


class FooState(State):
    """FooState class (inherits from State class)"""

    def __init__(self, node: Node):
        """Class initialization method

        Args:
            node (Node): Node class object
        """
        # Override the constructor of the inherited State class
        # The outcomes argument specifies the possible results to return when the state completes
        super().__init__(outcomes=["outcome1", "outcome2"])

        # Create an instance of the Node object
        self.node = node

    def execute(self, blackboard: Blackboard) -> str:
        """
        FOO state execution method

        Args:
            blackboard (CustomBlackboard): CustomBlackboard object

        Returns:
            str: outcomes string
        """
        # Display log
        self.node.get_logger().info("Executing state FOO")

        # Wait for 3 seconds
        self.node.get_clock().sleep_for(Duration(seconds=3))

        if blackboard.foo_counter_in < 3:
            blackboard.foo_counter_in += 1
            blackboard.foo_counter_out = blackboard.foo_counter_in
            return "outcome1"
        else:
            return "outcome2"
