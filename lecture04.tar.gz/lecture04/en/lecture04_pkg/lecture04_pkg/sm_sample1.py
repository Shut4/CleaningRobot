#!/usr/bin/env python3
# -*-encoding:UTF-8-*-

"""
File: sm_sample.py
Author: Tomoaki Fujino（Kyushu Institute of Technology, Hibikino-Musashi@Home）
"""

# Import modules (ROS2 related)
import rclpy
from rclpy.node import Node

# Import modules (YASMIN related)
# https://github.com/uleroboticsgroup/yasmin.git
from yasmin import StateMachine
from yasmin_viewer import YasminViewerPub

# Import modules (Custom: Each state)
from .state_sample1 import foo, bar


class StateMachineNode(Node):
    """StateMachineNode class (inherits from Node class)
    Node class that executes the state machine
    """

    def __init__(self):
        """Class initialization method"""
        # Override the constructor of the inherited Node class (argument is 'node name')
        super().__init__("sm_sample1")

        # Create an instance of the StateMachine class
        sm = StateMachine(outcomes=["EXIT"])

        # Add FOO state to the state machine
        sm.add_state(
            name="FOO",  # State name
            state=foo.FooState(node=self),  # State to execute
            transitions={  # Dictionary defining transitions to next states
                "outcome1": "BAR",  # Transition to BAR state when "outcome1" is returned
                "outcome2": "EXIT",  # Transition to EXIT when "outcome2" is returned
            },
        )

        # Add BAR state to the state machine
        sm.add_state(
            name="BAR",  # State name
            state=bar.BarState(node=self),  # State to execute
            transitions={  # Dictionary defining transitions to next states
                "outcome2": "FOO"  # Transition to FOO state when "outcome2" is returned
            },
        )

        # Publish state machine information to Yasmin Viewer
        YasminViewerPub(fsm_name="SM_SAMPLE1", fsm=sm)

        # Execute the state machine
        outcome = sm()

        # Display log
        self.get_logger().info("State Machine finished with outcome: " + outcome)


def main(args=None):
    """Main function"""
    # Initialize the ROS2 Python client library
    rclpy.init(args=args)

    # Create an instance of the StateMachineNode class
    node = StateMachineNode()

    # Cleanup
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
